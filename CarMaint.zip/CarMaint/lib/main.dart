import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/booking_screen.dart';
import 'screens/cart_screen.dart';
import 'screens/my_bookings_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/settings_screen.dart';
import 'widgets/right_drawer.dart';

void main() {
  runApp(const CarWashApp());
}

class CarWashApp extends StatelessWidget {
  const CarWashApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Car Wash Booking',
      theme: ThemeData(
        primarySwatch: Colors.green,
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6B8E23), // Olive Green
          brightness: Brightness.light,
        ),
      ),
      home: const MainApp(),
    );
  }
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  int _selectedIndex = 0;
  int _previousIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _previousIndex = _selectedIndex;
      _selectedIndex = index;
    });
  }

  void _goToMyBookings() {
    setState(() {
      _previousIndex = _selectedIndex;
      _selectedIndex = 4; // MyBookings is index 4
    });
  }

  void _closeMyBookings() {
    setState(() {
      _selectedIndex = _previousIndex;
    });
  }

  Widget _buildScreen(int index) {
    switch (index) {
      case 0:
        return const HomeScreen();
      case 1:
        return const BookingScreen();
      case 2:
        return const CartScreen();
      case 3:
        return const ProfileScreen();
      case 4:
        return MyBookingsScreen(onClose: _closeMyBookings);
      default:
        return const HomeScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _buildScreen(_selectedIndex),
      endDrawer: RightDrawer(
        onBook: () {
          Navigator.pop(context);
          setState(() {
            _selectedIndex = 1;
          });
        },
        onSettings: () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (context) => const SettingsScreen()));
        },
        onAbout: () {
          Navigator.pop(context);
          _showAboutDialog(context);
        },
        onSupport: () {
          Navigator.pop(context);
          _showSupportDialog(context);
        },
        onMyBookings: () {
          Navigator.pop(context);
          _goToMyBookings();
        },
      ),
      bottomNavigationBar: _selectedIndex == 4
          ? null
          : BottomNavigationBar(
              items: const <BottomNavigationBarItem>[
                BottomNavigationBarItem(
                  icon: Icon(Icons.home),
                  label: 'Home',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.add_circle),
                  label: 'Book',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.shopping_cart),
                  label: 'Cart',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.person),
                  label: 'Profile',
                ),
              ],
              currentIndex: _selectedIndex,
              selectedItemColor: const Color(0xFF6B8E23),
              unselectedItemColor: Colors.grey[600],
              backgroundColor: Colors.white,
              type: BottomNavigationBarType.fixed,
              onTap: _onItemTapped,
            ),
    );
  }

  void _showAboutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('About Car Wash Pro'),
        content: const SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Car Wash Pro is your ultimate car cleaning solution.',
                style: TextStyle(fontSize: 14),
              ),
              SizedBox(height: 12),
              Text(
                'Features:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text('• Premium car washing services'),
              Text('• Real-time availability tracking'),
              Text('• Loyalty rewards program'),
              Text('• 24/7 booking support'),
              SizedBox(height: 12),
              Text(
                'Contact: support@carwashpro.com',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showSupportDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Support & Help'),
        content: const SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'How can we help?',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBox(height: 12),
              Text('📞 Phone: +1 800-CARWASH'),
              SizedBox(height: 8),
              Text('📧 Email: support@carwashpro.com'),
              SizedBox(height: 8),
              Text('💬 Live Chat: Available 24/7'),
              SizedBox(height: 12),
              Text(
                'FAQ:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text('• How to cancel a booking?'),
              Text('• How to apply a discount code?'),
              Text('• What payment methods do you accept?'),
              Text('• Can I reschedule my booking?'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}
