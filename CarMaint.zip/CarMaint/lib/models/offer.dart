class Offer {
  final String id;
  final String title;
  final String description;
  final int discountPercent;
  final String validUntil;
  final String imageUrl;

  Offer({
    required this.id,
    required this.title,
    required this.description,
    required this.discountPercent,
    required this.validUntil,
    required this.imageUrl,
  });

  factory Offer.fromJson(Map<String, dynamic> json) {
    return Offer(
      id: json['id'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      discountPercent: json['discountPercent'] as int,
      validUntil: json['validUntil'] as String,
      imageUrl: json['imageUrl'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'discountPercent': discountPercent,
      'validUntil': validUntil,
      'imageUrl': imageUrl,
    };
  }
}
