class CartItem {
  final String serviceId;
  final String serviceName;
  final double price;
  final int quantity;
  final DateTime bookingDate;
  final String timeSlot;

  CartItem({
    required this.serviceId,
    required this.serviceName,
    required this.price,
    required this.quantity,
    required this.bookingDate,
    required this.timeSlot,
  });

  double get totalPrice => price * quantity;

  factory CartItem.fromJson(Map<String, dynamic> json) {
    return CartItem(
      serviceId: json['serviceId'] as String,
      serviceName: json['serviceName'] as String,
      price: (json['price'] as num).toDouble(),
      quantity: json['quantity'] as int,
      bookingDate: DateTime.parse(json['bookingDate'] as String),
      timeSlot: json['timeSlot'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'serviceId': serviceId,
      'serviceName': serviceName,
      'price': price,
      'quantity': quantity,
      'bookingDate': bookingDate.toIso8601String(),
      'timeSlot': timeSlot,
    };
  }
}
