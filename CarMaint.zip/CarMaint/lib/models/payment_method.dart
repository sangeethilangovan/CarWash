class PaymentMethod {
  final String id;
  final String type; // credit_card, debit_card, wallet, upi
  final String name;
  final String lastDigits;
  final bool isDefault;
  final DateTime addedAt;

  PaymentMethod({
    required this.id,
    required this.type,
    required this.name,
    required this.lastDigits,
    required this.isDefault,
    required this.addedAt,
  });

  factory PaymentMethod.fromJson(Map<String, dynamic> json) {
    return PaymentMethod(
      id: json['id'] as String,
      type: json['type'] as String,
      name: json['name'] as String,
      lastDigits: json['lastDigits'] as String,
      isDefault: json['isDefault'] as bool,
      addedAt: DateTime.parse(json['addedAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type,
      'name': name,
      'lastDigits': lastDigits,
      'isDefault': isDefault,
      'addedAt': addedAt.toIso8601String(),
    };
  }
}
