class Favorite {
  final String serviceId;
  final String serviceName;
  final double price;
  final DateTime addedAt;

  Favorite({
    required this.serviceId,
    required this.serviceName,
    required this.price,
    required this.addedAt,
  });

  factory Favorite.fromJson(Map<String, dynamic> json) {
    return Favorite(
      serviceId: json['serviceId'] as String,
      serviceName: json['serviceName'] as String,
      price: (json['price'] as num).toDouble(),
      addedAt: DateTime.parse(json['addedAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'serviceId': serviceId,
      'serviceName': serviceName,
      'price': price,
      'addedAt': addedAt.toIso8601String(),
    };
  }
}
