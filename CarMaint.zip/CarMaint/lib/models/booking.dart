class Booking {
  final String id;
  final String serviceId;
  final String serviceName;
  final DateTime bookingDate;
  final String timeSlot;
  final String location;
  final double totalPrice;
  final String status; // pending, confirmed, completed, cancelled
  final String carPlate;
  final String carModel;
  final DateTime createdAt;

  Booking({
    required this.id,
    required this.serviceId,
    required this.serviceName,
    required this.bookingDate,
    required this.timeSlot,
    required this.location,
    required this.totalPrice,
    required this.status,
    required this.carPlate,
    required this.carModel,
    required this.createdAt,
  });

  factory Booking.fromJson(Map<String, dynamic> json) {
    return Booking(
      id: json['id'] as String,
      serviceId: json['serviceId'] as String,
      serviceName: json['serviceName'] as String,
      bookingDate: DateTime.parse(json['bookingDate'] as String),
      timeSlot: json['timeSlot'] as String,
      location: json['location'] as String,
      totalPrice: (json['totalPrice'] as num).toDouble(),
      status: json['status'] as String,
      carPlate: json['carPlate'] as String,
      carModel: json['carModel'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'serviceId': serviceId,
      'serviceName': serviceName,
      'bookingDate': bookingDate.toIso8601String(),
      'timeSlot': timeSlot,
      'location': location,
      'totalPrice': totalPrice,
      'status': status,
      'carPlate': carPlate,
      'carModel': carModel,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}
