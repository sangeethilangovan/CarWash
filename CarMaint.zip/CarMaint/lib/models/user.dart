class User {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String profileImage;
  final String memberSince;
  final double totalSpent;
  final int totalBookings;
  final double rating;

  User({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.profileImage,
    required this.memberSince,
    required this.totalSpent,
    required this.totalBookings,
    required this.rating,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] as String,
      name: json['name'] as String,
      email: json['email'] as String,
      phone: json['phone'] as String,
      profileImage: json['profileImage'] as String,
      memberSince: json['memberSince'] as String,
      totalSpent: (json['totalSpent'] as num).toDouble(),
      totalBookings: json['totalBookings'] as int,
      rating: (json['rating'] as num).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'profileImage': profileImage,
      'memberSince': memberSince,
      'totalSpent': totalSpent,
      'totalBookings': totalBookings,
      'rating': rating,
    };
  }
}
