import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../widgets/profile_details_sheet.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isUserLoggedIn = false;
  int _loyaltyPoints = 250;
  int _nextMilestone = 500;
  bool _isFirstTimeUser = true;
  int _consecutiveBookings = 4;
  DateTime? _lastBookingDate;

  final List<Map<String, dynamic>> services = [
    {
      'name': 'Basic Wash',
      'price': '\$15',
      'duration': '30 min',
      'icon': Icons.local_car_wash,
      'rating': 4.2,
      'reviews': 145,
      'available': 8,
    },
    {
      'name': 'Premium Wash',
      'price': '\$25',
      'duration': '45 min',
      'icon': Icons.local_car_wash,
      'rating': 4.7,
      'reviews': 312,
      'available': 5,
    },
    {
      'name': 'Deluxe Wash',
      'price': '\$40',
      'duration': '60 min',
      'icon': Icons.local_car_wash,
      'rating': 4.9,
      'reviews': 89,
      'available': 3,
    },
    {
      'name': 'Interior Clean',
      'price': '\$20',
      'duration': '30 min',
      'icon': Icons.cleaning_services,
      'rating': 4.5,
      'reviews': 156,
      'available': 10,
    },
  ];

  final List<Map<String, dynamic>> offers = [
    {
      'title': '20% OFF',
      'description': 'First Time Booking',
      'discount': '20%',
      'validUntil': 'Unlimited',
      'isActive': true,
    },
    {
      'title': 'FREE',
      'description': 'After 4 Bookings',
      'discount': 'Free Wash',
      'validUntil': '6 Months',
      'isActive': true,
    },
    {
      'title': 'Buy 2 Get 1',
      'description': 'Any Service',
      'discount': '33% OFF',
      'validUntil': 'Jan 20, 2026',
      'isActive': true,
    },
    {
      'title': 'Bundle Deal',
      'description': 'Wash + Interior',
      'discount': '\$15 OFF',
      'validUntil': 'Jan 18, 2026',
      'isActive': true,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
      appBar: AppBar(
        title: const Text('Car Wash Booking'),
        elevation: 2,
        backgroundColor: const Color(0xFF6B8E23),
        foregroundColor: Colors.white,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Color(0xFF6B8E23),
          statusBarBrightness: Brightness.light,
          statusBarIconBrightness: Brightness.light,
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: GestureDetector(
              onTap: () {
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                  ),
                  builder: (context) => DraggableScrollableSheet(
                    initialChildSize: 0.8,
                    maxChildSize: 0.95,
                    minChildSize: 0.5,
                    builder: (context, scrollController) => SingleChildScrollView(
                      controller: scrollController,
                      child: ProfileDetailsSheet(
                        isLoggedIn: _isUserLoggedIn,
                        onLogin: () {
                          setState(() {
                            _isUserLoggedIn = true;
                          });
                        },
                        onLogout: () {
                          setState(() {
                            _isUserLoggedIn = false;
                          });
                        },
                      ),
                    ),
                  ),
                );
              },
              child: Stack(
                children: [
                  CircleAvatar(
                    backgroundColor: _isUserLoggedIn ? const Color(0xFF6B8E23) : Colors.grey[300],
                    child: Icon(
                      Icons.account_circle,
                      size: 28,
                      color: _isUserLoggedIn ? Colors.white : Colors.grey[600],
                    ),
                  ),
                  if (!_isUserLoggedIn)
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(
                          Icons.close,
                          size: 10,
                          color: Colors.white,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(context).openEndDrawer(),
            tooltip: 'Open Menu',
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Banner with Loyalty Points
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF6B8E23), Color(0xFF8CAE3C), Color(0xFF7BA428)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Loyalty Points Card
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.star, color: Colors.amber, size: 24),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Loyalty Points', style: TextStyle(color: Colors.white70, fontSize: 12)),
                              Text(
                                '$_loyaltyPoints / $_nextMilestone',
                                style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          '${((_loyaltyPoints / _nextMilestone) * 100).toStringAsFixed(0)}%',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    '🚗 Unlock Premium at 500 Points',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Quick Actions
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [Colors.blue[400]!, Colors.blue[600]!]),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.add, color: Colors.white, size: 18),
                          SizedBox(width: 6),
                          Text('Quick Book', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        border: Border.all(color: const Color(0xFF6B8E23), width: 2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.local_offer, color: Color(0xFF6B8E23), size: 18),
                          SizedBox(width: 6),
                          Text('Offers', style: TextStyle(color: Color(0xFF6B8E23), fontWeight: FontWeight.bold, fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Special Offers
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('🎉 Special Offers', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 130,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: offers.length,
                      itemBuilder: (context, index) {
                        final offer = offers[index];
                        return OfferCard(
                          title: offer['title'],
                          description: offer['description'],
                          discount: offer['discount'],
                          validUntil: offer['validUntil'],
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Services
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('✨ Popular Services', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      childAspectRatio: 0.95,
                    ),
                    itemCount: services.length,
                    itemBuilder: (context, index) {
                      final service = services[index];
                      return ServiceCard(
                        name: service['name'],
                        price: service['price'],
                        duration: service['duration'],
                        icon: service['icon'],
                        rating: service['rating'],
                        reviews: service['reviews'],
                        available: service['available'],
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
      ),
    );
  }
}

class ServiceCard extends StatelessWidget {
  final String name;
  final String price;
  final String duration;
  final IconData icon;
  final double rating;
  final int reviews;
  final int available;

  const ServiceCard({
    super.key,
    required this.name,
    required this.price,
    required this.duration,
    required this.icon,
    this.rating = 4.5,
    this.reviews = 0,
    this.available = 0,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$name selected')),
        );
      },
      child: Card(
        elevation: 2,
        shadowColor: const Color(0xFF6B8E23).withOpacity(0.2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: LinearGradient(
              colors: [Colors.white, Colors.grey[50]!],
            ),
          ),
          padding: const EdgeInsets.all(8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Icon
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: const Color(0xFF6B8E23).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Icon(icon, size: 28, color: const Color(0xFF6B8E23)),
              ),
              // Name
              Text(
                name,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, height: 1),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              // Rating
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.star, color: Colors.amber, size: 10),
                  Text('$rating', style: const TextStyle(fontSize: 8)),
                ],
              ),
              // Availability
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                decoration: BoxDecoration(
                  color: available > 5 ? Colors.green[100] : Colors.orange[100],
                  borderRadius: BorderRadius.circular(3),
                ),
                child: Text(
                  '$available✓',
                  style: TextStyle(fontSize: 7, color: available > 5 ? Colors.green[700] : Colors.orange[700], fontWeight: FontWeight.bold),
                ),
              ),
              // Price
              Text(price, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF6B8E23))),
            ],
          ),
        ),
      ),
    );
  }
}class OfferCard extends StatelessWidget {
  final String title;
  final String description;
  final String discount;
  final String validUntil;

  const OfferCard({
    super.key,
    required this.title,
    required this.description,
    required this.discount,
    required this.validUntil,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$title offer applied!')),
        );
      },
      child: Container(
        width: 200,
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.orange[400]!, Colors.orange[600]!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Save: $discount',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                Text(
                  'Valid until: $validUntil',
                  style: const TextStyle(
                    fontSize: 10,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}