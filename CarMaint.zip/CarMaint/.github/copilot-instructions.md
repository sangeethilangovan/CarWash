# Copilot Instructions for Car Wash Booking App

## Project Overview
**Car Wash Booking** is a feature-rich Flutter cross-platform mobile app for browsing car wash services, booking appointments, managing shopping cart, and tracking reservations. Built with Material 3 design, provider state management, and comprehensive user features.

## ✨ Key Features Implemented

### Core Features
1. **User Authentication** - Profile icon login, user details, logout
2. **Service Search & Filter** - Real-time search and filter by service type
3. **Service Details with Reviews** - View ratings, read/write reviews
4. **Favorites/Wishlist** - Add/remove favorite services
5. **Shopping Cart** - Add services, adjust quantities, calculate totals
6. **Booking Management** - View booking history with status
7. **Special Offers** - Scrollable promotional offers with discounts
8. **Settings** - Notifications, appearance, account settings
9. **Payment Methods** - Support for multiple payment types
10. **Profile Management** - User info, statistics, settings

### Navigation Structure
- **5-Tab Bottom Navigation**:
  - Tab 0: `HomeScreen` - service browsing + profile access
  - Tab 1: `BookingScreen` - create new bookings
  - Tab 2: `CartScreen` - manage shopping cart
  - Tab 3: `MyBookingsScreen` - view reservation history
  - Tab 4: `ProfileScreen` - user account settings

### Data Models
Core models in `lib/models/`:
- **`CarWashService`**: Service catalog with id, name, description, price, duration, features, imageUrl, rating, reviewCount
- **`Booking`**: Reservation with id, serviceId, serviceName, bookingDate, timeSlot, location, totalPrice, status, carPlate, carModel, createdAt
- **`CartItem`**: Shopping cart item with serviceId, serviceName, price, quantity, bookingDate, timeSlot, totalPrice calculation
- **`User`**: User profile with id, name, email, phone, profileImage, memberSince, totalSpent, totalBookings, rating
- **`Favorite`**: Wishlist item with serviceId, serviceName, price, addedAt timestamp
- **`Review`**: Customer review with id, serviceId, userName, rating, comment, createdAt
- **`Offer`**: Promotional offer with id, title, description, discountPercent, validUntil, imageUrl
- **`PaymentMethod`**: Payment option with id, type (credit_card/debit_card/wallet/upi), name, lastDigits, isDefault, addedAt
- All models implement `fromJson()` and `toJson()` factory methods
- **Always use DateTime.parse() and .toIso8601String()** for date serialization

### State Management
- **Provider v6.0.0** is the designated state management solution
- Models should be wrapped in `ChangeNotifier` providers for reactive updates
- Avoid mixing Provider with InheritedWidget; keep Provider as single source of truth

### Backend Integration
- **Firebase**: `firebase_auth` (user auth), `cloud_firestore` (data), `firebase_core` (initialization)
- **HTTP Client**: `http` package for REST APIs alongside Firebase
- **Location Services**: `geolocator` and `google_maps_flutter` for location-based features

## Development Workflows

### Setup & Run
```bash
flutter pub get                    # Get dependencies
flutter run                        # Run on connected device
flutter run -d chrome             # Run on web
flutter build apk                 # Build Android
flutter build ios                 # Build iOS
```

### Testing
- Use `flutter test` for unit/widget tests
- Configured with `flutter_linter` for code analysis
- Run `flutter analyze` before committing

## Code Conventions

### Dart/Flutter Style
- **Const constructors**: Always use `const` for constructors (`const SizedBox(height: 8)`)
- **Named parameters**: Constructor parameters use `required` keyword explicitly
- **Naming**: PascalCase for classes, camelCase for variables/methods, snake_case for assets
- **Keys**: Include `Key? key` and `super(key: key)` in all StatelessWidget/StatefulWidget constructors

### Screen State Patterns
- **HomeScreen** (`_HomeScreenState`): Manages mock service data as `final List<Map<String, dynamic>> services`. Use `GridView.builder()` with `NeverScrollableScrollPhysics` when nested in `SingleChildScrollView`. Services include banner and title sections before grid
- **BookingScreen** (`_BookingScreenState`): Maintains form state with separate fields: `selectedDate`, `selectedTimeSlot`, `selectedService`, `carPlate`, `carModel`. Time slots and services stored as `final List<String>`. Form uses `DropdownButton` for service/time selection and date/time pickers
- **MyBookingsScreen** (`_MyBookingsScreenState`): Displays bookings list from `List<Map<String, dynamic>>` with status field. Implement empty state with centered icon and message when list is empty
- **ProfileScreen** (`_ProfileScreenState`): Follows similar pattern for user settings display

### UI Component Conventions
- Use `SingleChildScrollView` as root for screens with scrollable content
- Implement `AppBar` with title in all screens using `Scaffold`
- Use `Card` widgets for list items with `elevation: 2` and `borderRadius: BorderRadius.circular(12)`
- Text hierarchy: Use `fontSize: 24, fontWeight: FontWeight.bold` for headings, `fontSize: 14/12` for body text
- Spacing: Default padding `const EdgeInsets.all(16)` for screen body, `const SizedBox(height: 8/16/20)` for internal spacing

### Asset Organization
```
assets/
├── images/          # Service photos, banners
├── icons/           # Custom app icons
├── fonts/           # Poppins font family (Regular, Bold)
```

## Key File Responsibilities

| File | Purpose |
|------|---------|
| [lib/main.dart](lib/main.dart) | App bootstrap, material theme setup, MainApp navigation shell |
| [lib/models/](lib/models/) | All data models (CarWashService, Booking, User, Review, Favorite, etc.) |
| [lib/screens/home_screen.dart](lib/screens/home_screen.dart) | Service browsing, offers carousel, profile icon integration |
| [lib/screens/booking_screen.dart](lib/screens/booking_screen.dart) | Booking form: service select → date → time → confirmation |
| [lib/screens/cart_screen.dart](lib/screens/cart_screen.dart) | Shopping cart with quantity adjustment and checkout |
| [lib/screens/my_bookings_screen.dart](lib/screens/my_bookings_screen.dart) | List bookings, status filtering, cancel/rebook actions |
| [lib/screens/profile_screen.dart](lib/screens/profile_screen.dart) | User account info, settings, payment methods |
| [lib/screens/favorites_screen.dart](lib/screens/favorites_screen.dart) | Wishlist view with add-to-cart functionality |
| [lib/screens/settings_screen.dart](lib/screens/settings_screen.dart) | Notifications, appearance, account, help settings |
| [lib/screens/service_details_screen.dart](lib/screens/service_details_screen.dart) | Service details, reviews, ratings, favorite toggle |
| [lib/widgets/profile_details_sheet.dart](lib/widgets/profile_details_sheet.dart) | Login modal, user profile display, logout |
| [lib/widgets/search_filter_widget.dart](lib/widgets/search_filter_widget.dart) | Search bar and filter chips component |

## Feature Implementation Patterns

### Search & Filter
- HomeScreen integrates `SearchAndFilterWidget` for real-time service search
- Filter chips for: All, Wash, Interior, Premium
- Search updates service grid dynamically

### Favorites System
- Icon toggle in ServiceCard and ServiceDetailsScreen
- Persistent favorite state per session
- Dedicated FavoritesScreen for management
- Quick "Add to Cart" from favorites

### Reviews & Ratings
- ServiceDetailsScreen displays overall rating (4.8/5)
- Review count (234+)
- Individual review cards with user name, rating, comment, date
- Star rating input for writing new reviews
- Submit review functionality

### Profile & Authentication
- ProfileDetailsSheet modal (bottom sheet)
- Login form with email/password fields
- User profile view with avatar (initials), stats
- Logout button with confirmation
- Profile icon status indicator (blue=logged in, grey=logged out)

### Settings Management
- SettingsScreen with organized sections:
  - Notifications (push, email, SMS toggles)
  - Appearance (theme selection)
  - Account (password, privacy, terms)
  - Help (FAQ, contact, about)
- Uses SwitchListTile and ListTile for UI

### Payment Methods
- Multiple payment type support (credit/debit/wallet/UPI)
- Default payment selection
- Last 4 digits masking
- Add/remove payment methods

## Cross-Component Communication
- **Service → Booking Flow**: HomeScreen navigates to BookingScreen; pass selected service via Provider or constructor
- **Booking Persistence**: Save bookings to Firestore via `cloud_firestore` after confirmation
- **Real-time Updates**: Use `StreamBuilder` with Firestore listeners for live booking status updates in MyBookingsScreen
- **Location Integration**: Use `geolocator` to detect user location on HomeScreen; filter nearby services via `google_maps_flutter`

## Dependency Versions (Lock Pattern)
- Flutter SDK: ≥3.0.0 <4.0.0
- provider: ^6.0.0 (state management)
- firebase_core/auth/firestore: v4.x (aligned Firebase package versions)
- intl: ^0.19.0 (date formatting)
- google_fonts: ^6.1.0 (typography)

## Testing & Quality
- Run `flutter analyze` before code review
- Use `flutter_test` for widget testing
- Prefer `testWidgets()` for UI interactions over unit tests where state matters
